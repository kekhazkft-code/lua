# Sinum Platform UI System Guide

## Overview

The Sinum platform uses a declarative JSON-based UI system with three main areas:
1. **Widget** - Main display/dashboard (shown on touchscreen)
2. **Config** - Settings/configuration panel
3. **Dialog** - Modal dialogs

Each area contains a hierarchical layout of **rows**, **cells**, and **elements**.

---

## Quick Reference: All UI Element Types

| Type | Purpose | Callback | Interactive |
|------|---------|----------|-------------|
| `text` | Display labels/values | `on_change` (optional) | Read-only or editable |
| `slider` | Range input | `on_change` | ✅ Yes |
| `switcher` | Boolean toggle | `on_change` | ✅ Yes |
| `combo_box` | Dropdown selection | `on_change` | ✅ Yes |
| `button` | Action trigger | `on_press` | ✅ Yes |
| `color_picker` | RGB/temp color | `on_color_change`, `on_brightness_change`, `on_state_change` | ✅ Yes |
| `device_selector` | Select devices | `on_change` | ✅ Yes |

---

## 1. UI Structure Hierarchy

```
Device JSON
├── elements[]           # All UI element definitions
├── widget              # Main display layout
│   └── content[]       # Rows and sections
├── config              # Settings panel layout
│   └── content[]       # Rows
└── dialog              # Modal dialog layout
    └── content[]       # Rows
```

---

## 2. Layout Components

### 2.1 Row
Container for horizontal arrangement of cells.

```json
{
  "id": "unique-uuid",
  "type": "row",
  "cells": [...]
}
```

### 2.2 Section
Grouping container with optional collapsibility (only in widget).

```json
{
  "id": "unique-uuid",
  "type": "section",
  "text": "Section Title",
  "text_id": 0,
  "collapsible": true,
  "collapsed_default": false,
  "has_background": false,
  "rows": [...],
  "cells": []
}
```

### 2.3 Cell
Container for elements within a row.

```json
{
  "id": "unique-uuid",
  "elements": [
    { "uuid": "element-uuid", "variant": "text-default" }
  ],
  "orientation": "row|column",
  "horizontal_alignment": "start|center|end",
  "vertical_alignment": "start|center|end"
}
```

**Key Properties:**
- `orientation`: How elements stack (`row` = horizontal, `column` = vertical)
- `horizontal_alignment`: Element alignment within cell
- `vertical_alignment`: Element alignment within cell

---

## 3. UI Element Types

### 3.1 Text (Display)
Static or dynamic text display.

```json
{
  "type": "text",
  "name": "temperature_display",
  "uuid": "unique-uuid",
  "value": "26.5°C",
  "enabled": true,
  "visibility": "visible",
  "font_size": "normal|large",
  "font_weight": "normal|bold",
  "icon": "",
  "on_change": "",
  "text_id": 0
}
```

**Lua Access:**
```lua
-- Read
self:getElement('temperature_display'):getValue('value')

-- Write
self:getElement('temperature_display'):setValue('value', '28.3°C', true)
```

### 3.2 Slider (Input)
Range input control with drag interaction.

```json
{
  "type": "slider",
  "name": "slider_1",
  "uuid": "unique-uuid",
  "value": 17.0,
  "minimum": 0.0,
  "maximum": 30.0,
  "step": 1.0,
  "unit": "°C",
  "label_text": "Kamra cél hőmérséklet:",
  "label_text_id": 0,
  "enabled": true,
  "visibility": "visible",
  "on_change": "on_Target_TemperatureChange"
}
```

**Lua Callback:**
```lua
function CustomDevice:on_Target_TemperatureChange(newValue, element)
  -- newValue is the slider's new value (as number)
  local target_temp = newValue * 10  -- Convert to int*10 format
  kamra_cel_homerseklet_v1:setValue(target_temp, false)
end
```

**Lua Access:**
```lua
-- Read
local value = self:getElement('slider_1'):getValue('value')

-- Write
self:getElement('slider_1'):setValue('value', 20.0, true)
```

### 3.3 Switcher (Toggle)
Boolean on/off toggle.

```json
{
  "type": "switcher",
  "name": "simulation_toggle",
  "uuid": "unique-uuid",
  "value": false,
  "enabled": true,
  "visibility": "visible",
  "on_change": "onSimulationToggle"
}
```

**Lua Callback:**
```lua
function CustomDevice:onSimulationToggle(newValue, element)
  -- newValue is boolean (true/false)
  if newValue then
    print("Simulation enabled")
  else
    print("Simulation disabled")
  end
end
```

### 3.4 Combo Box (Dropdown)
Selection from predefined options.

```json
{
  "type": "combo_box",
  "name": "baudrate",
  "uuid": "unique-uuid",
  "value": "9600",
  "enabled": true,
  "visibility": "visible",
  "on_change": "onBaudrate",
  "options": [
    { "label": "115200", "value": "115200", "text_id": 0 },
    { "label": "57600", "value": "57600", "text_id": 0 },
    { "label": "9600", "value": "9600", "text_id": 0 }
  ]
}
```

**Lua Callback:**
```lua
function CustomDevice:onBaudrate(newValue)
  -- newValue is the selected option's value (string)
  local com = self:getComponent('com')
  com:setValue('baud_rate', tonumber(newValue))
end
```

### 3.5 Button (Action)
Clickable button that triggers an action.

```json
{
  "type": "button",
  "name": "mode_cool",
  "uuid": "unique-uuid",
  "text": "Cooling",
  "text_id": 0,
  "icon": "snowflake",
  "enabled": true,
  "visibility": "visible",
  "on_press": "onModeCool"
}
```

**Available Icons:** `play`, `snowflake`, `heat`, `power`, etc.

**Lua Callback:**
```lua
function CustomDevice:onModeCool()
  -- Button press handler (no parameters)
  self:setMode(1)
end
```

**Note:** Buttons use `on_press` instead of `on_change`.

### 3.6 Color Picker
RGB/Temperature color selection with optional switch and brightness.

```json
{
  "type": "color_picker",
  "name": "color",
  "uuid": "unique-uuid",
  "color": "#e400ac",
  "color_mode": "rgb",
  "available_color_modes": ["rgb", "temperature"],
  "brightness": 100,
  "temperature": 5237,
  "state": true,
  "enabled": true,
  "visibility": "visible",
  "gradient_size_maximum": 2,
  "on_color_change": "onColor",
  "on_brightness_change": "onBrightness",
  "on_state_change": "onSwitch"
}
```

**Properties:**
- `color`: Hex color string (e.g., "#ff5938")
- `color_mode`: Current mode ("rgb" or "temperature")
- `available_color_modes`: Allowed modes
- `brightness`: 0-100 brightness value
- `temperature`: Color temperature in Kelvin
- `state`: On/off state (boolean)

**Lua Callbacks:**
```lua
function CustomDevice:onColor(color)
  -- color.color = "#rrggbb"
  -- color.color_mode = "rgb" or "temperature"
  local r = tonumber(color.color:sub(2, 3), 16)
  local g = tonumber(color.color:sub(4, 5), 16)
  local b = tonumber(color.color:sub(6, 7), 16)
  -- Process RGB values...
end

function CustomDevice:onBrightness(new)
  -- new = brightness value (0-100)
end

function CustomDevice:onSwitch(new)
  -- new = boolean on/off state
end
```

### 3.7 Device Selector
Select other devices on the network.

```json
{
  "type": "device_selector",
  "name": "xceiver",
  "uuid": "unique-uuid",
  "enabled": true,
  "visibility": "visible",
  "on_change": "onXceiver",
  "allow_multiple": false,
  "accepted_types": ["modbus_transceiver", "modbus_extender"],
  "accepted_classes": []
}
```

**Lua Callback:**
```lua
function CustomDevice:onXceiver(new)
  self:getComponent('com'):setValue('associations.transceiver', JSON:decode(new))
end
```

---

## 4. Element Variants (Layout References)

When referencing elements in layout, use variants to control appearance:

| Type | Variants | Description |
|------|----------|-------------|
| text | `text-default` | Standard text display |
| text | `text-input` | Editable text field |
| slider | `slider-default` | Basic slider |
| slider | `slider-with-label` | Slider with label above |
| slider | `slider-with-plus-minus-buttons` | Slider with +/- buttons |
| switcher | `switch-default` | Standard toggle switch |
| combo_box | `combo-box-default` | Standard dropdown |
| button | `button-default` | Standard button |
| device_selector | `device-selector-default` | Device picker |
| color_picker | `color-picker-switch` | Color picker with on/off |
| color_picker | `color-picker-both` | Full color picker |
| (layout) | `separator` | Visual separator line |

Example in layout:
```json
{
  "elements": [
    { "uuid": "slider-uuid", "variant": "slider-with-label" }
  ]
}
```

---

## 5. Complete Layout Examples

### 5.1 Main Display (Widget) with Sensor Data

```
┌─────────────────────────────────────────────────────────────┐
│ [SECTION: Outdoor]                                          │
│ ┌─────────────────┬─────────────────┬─────────────────────┐ │
│ │ Külső hőmérs.:  │     26.5°C      │ harmatpont: 7.4°C   │ │
│ │ Külső rel. pára:│     29.7%       │ absolut: 0.074g/m³  │ │
│ └─────────────────┴─────────────────┴─────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ [ROW: Supply Air]                                           │
│ ┌─────────────────┬─────────────────┬─────────────────────┐ │
│ │ Befújt hőmérs.: │     30.0°C      │ harmatpont: 23.0°C  │ │
│ │ Befújt pára:    │     52.5%       │ absolut: 0.200g/m³  │ │
│ └─────────────────┴─────────────────┴─────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ [ROW: Chamber]                                              │
│ ┌─────────────────┬─────────────────┬─────────────────────┐ │
│ │ Kamra hőmérs.:  │     26.4°C      │ harmatpont: 7.7°C   │ │
│ │ Kamra rel. pára:│     30.5%       │ absolut: 0.076g/m³  │ │
│ └─────────────────┴─────────────────┴─────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ [ROW: Setpoint Sliders]                                     │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ Kamra cél hőmérséklet: ═══════●═══════ 17°C            │ │
│ │ Kamra cél pára:        ═══════════●═══ 70%             │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ [ROW: Status]                                               │
│ ┌────────────────────────┬────────────────────────────────┐ │
│ │ Fűtés Aktív!           │ Hűtés Aktív!                   │ │
│ └────────────────────────┴────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 Settings Panel (Config)

```
┌─────────────────────────────────────────────────────────────┐
│ Modbus RTU parameters:                                      │
├─────────────────────────────────────────────────────────────┤
│ Used transceiver    │ [Device Selector ▼]                   │
├─────────────────────────────────────────────────────────────┤
│ Baud rate           │ [9600 ▼]                              │
├─────────────────────────────────────────────────────────────┤
│ Data bits           │ [8 ▼] (disabled)                      │
├─────────────────────────────────────────────────────────────┤
│ Parity bit          │ [None ▼]                              │
├─────────────────────────────────────────────────────────────┤
│ Stop bits           │ [1 ▼]                                 │
├─────────────────────────────────────────────────────────────┤
│ Slave ID            │ [5] (text input)                      │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Lua UI API Reference

### 6.1 Getting Elements
```lua
local element = self:getElement('element_name')
```

### 6.2 Reading Values
```lua
-- Get current value
local value = element:getValue('value')

-- Get other properties
local enabled = element:getValue('enabled')
local visible = element:getValue('visibility')
```

### 6.3 Writing Values
```lua
-- setValue(property, value, stop_propagation)
element:setValue('value', new_value, true)   -- Don't trigger on_change
element:setValue('value', new_value, false)  -- Trigger on_change

-- Set visibility
element:setValue('visibility', 'visible', true)
element:setValue('visibility', 'hidden', true)

-- Enable/disable
element:setValue('enabled', true, true)
element:setValue('enabled', false, true)
```

### 6.4 Dynamic Text Updates
```lua
-- Format and display temperature
local temp = kamra_homerseklet:getValue() / 10
self:getElement('_3_tx_kamra_homerseklet_'):setValue(
  'value', 
  string.format('%.1f°C', temp), 
  true
)

-- Format and display humidity
local humi = kamra_para:getValue() / 10
self:getElement('_4_tx_kamra_para_'):setValue(
  'value', 
  string.format('%.1f%%', humi), 
  true
)
```

---

## 7. Naming Conventions

Observed naming patterns in the codebase:

| Pattern | Meaning | Example |
|---------|---------|---------|
| `_N_lb_*` | Label (static text) | `_1_lb_befujt_homerseklet_` |
| `_N_tx_*` | Text display (dynamic) | `_1_tx_befujt_homerseklet_` |
| `slider_N` | Slider control | `slider_0`, `slider_1` |
| `*_switcher` | Toggle switch | `kamra_szimul_switcher` |
| `text_input_N_*` | Status text | `text_input_0_warm` |
| `dp_*_tx` | Dew point display | `dp_kamra_tx` |
| `ah_*_tx` | Absolute humidity display | `ah_kamra_tx` |

---

## 8. Simulation Device UI

The simulation device (`erlelo_simu`) adds extra controls:

### Additional Switchers (Toggles)
- `KulsoSwitcher_0` - Enable outdoor simulation
- `kamra_szimul_switcher` - Enable chamber simulation  
- `befujt_switcher` - Enable supply air simulation

### Additional Sliders
- `slider_0` / `slider_1` - Outdoor temp/humidity simulation
- `kamra_hom_szimul` / `kamra_para_szimul` - Chamber simulation
- `befujt_hom_slider` / `befujt_para_slider` - Supply air simulation

---

## 9. Best Practices

### 9.1 UI Updates
```lua
-- Always use true for stop_propagation when updating display-only elements
self:getElement('display_text'):setValue('value', 'New Value', true)

-- Use false only when the change should trigger other callbacks
self:getElement('setpoint_slider'):setValue('value', 25.0, false)
```

### 9.2 Formatting
```lua
-- Temperature (with degree symbol)
string.format('%.1f°C', temp)

-- Humidity (with percent)
string.format('%.1f%%', humidity)

-- Absolute humidity
string.format('%.3fg/m³', ah)
```

### 9.3 Conditional Visibility
```lua
-- Hide element when in error state
if error_flag then
  self:getElement('normal_display'):setValue('visibility', 'hidden', true)
  self:getElement('error_display'):setValue('visibility', 'visible', true)
else
  self:getElement('normal_display'):setValue('visibility', 'visible', true)
  self:getElement('error_display'):setValue('visibility', 'hidden', true)
end
```

---

## 10. Element UUID Reference

Elements are referenced in layouts by UUID. The layout structure connects:

1. **Elements array**: Defines properties (name, type, value, callbacks)
2. **Layout cells**: Reference elements by UUID with display variant

```json
// In elements[]
{
  "name": "slider_1",
  "uuid": "8e6dede4-af1f-46f8-9c1b-357b45d4f115",
  "type": "slider",
  "on_change": "on_Target_TemperatureChange",
  ...
}

// In widget.content[].cells[].elements[]
{
  "uuid": "8e6dede4-af1f-46f8-9c1b-357b45d4f115",
  "variant": "slider-with-label"
}
```

This separation allows the same element to potentially appear in multiple layouts with different visual variants.

---

## 11. Real-World Device Examples

### 11.1 Heat Pump Controller (Samsung HE)
```
Widget Layout:
┌─────────────────────────────────────────────────────┐
│ [switcher] ON/OFF    │  Room: [text] 22.5°C        │
├─────────────────────────────────────────────────────┤
│ Setpoint: [text]     │  [slider] ═══●═══ 23°C     │
├─────────────────────────────────────────────────────┤
│ [button] Auto  [button] Cool  [button] Heat        │
├─────────────────────────────────────────────────────┤
│ [switcher] DHW       │  Tank: [text] 45.0°C        │
├─────────────────────────────────────────────────────┤
│ DHW Setpoint:        │  [slider] ═══●═══ 50°C     │
└─────────────────────────────────────────────────────┘
```

### 11.2 Smart Light Controller (Hue)
```
Widget Layout:
┌─────────────────────────────────────────────────────┐
│ [color_picker] 🎨 RGB/Temp  │  [combo_box] Effect ▼│
├─────────────────────────────────────────────────────┤
│ Brightness: [slider] ════════●════════ 75%         │
└─────────────────────────────────────────────────────┘
```

### 11.3 AC Controller (XK76)
```
Widget Layout:
┌─────────────────────────────────────────────────────┐
│ Power:        │ [switcher] ON/OFF                   │
├─────────────────────────────────────────────────────┤
│ Mode:         │ [combo_box] Cooling ▼               │
├─────────────────────────────────────────────────────┤
│ Outdoor:      │ [text] 32.5°C                       │
├─────────────────────────────────────────────────────┤
│ Indoor:       │ [text] 24.0°C  →  [text] 22°C      │
├─────────────────────────────────────────────────────┤
│ [slider with +/- buttons] ═════●═════ 22°C         │
├─────────────────────────────────────────────────────┤
│ Fan:          │ [combo_box] Auto ▼                  │
├─────────────────────────────────────────────────────┤
│ [switcher] Quiet  [switcher] Turbo  [switcher] Away│
└─────────────────────────────────────────────────────┘
```

---

## 12. Device Components Reference

Components are hardware/protocol interfaces available to the Lua code:

| Component Type | Purpose | Access |
|----------------|---------|--------|
| `modbus_rtu_client` | RS-485 Modbus communication | `self:getComponent('com')` |
| `timer` | Periodic/one-shot timers | `self:getComponent('timer')` |
| `http_client` | HTTP requests | `self:getComponent('http')` |
| `variable_string` | String storage | Direct variable access |
| `variable_boolean` | Boolean storage | Direct variable access |

### Component Example (Modbus)
```lua
function CustomDevice:onInit()
  local com = self:getComponent('com')
  
  -- Read configuration
  local baud = com:getValue('baud_rate')
  local slave = com:getValue('slave_address')
  
  -- Async read
  com:readInputRegistersAsync(1, 2)
  
  -- Async write  
  com:writeHoldingRegisterAsync(18, 230)
end
```

---

## 13. Callback Parameter Reference

| Element Type | Callback | Parameter |
|--------------|----------|-----------|
| slider | `on_change` | `newValue` (number) |
| switcher | `on_change` | `newValue` (boolean) |
| combo_box | `on_change` | `newValue` (string - option value) |
| button | `on_press` | (none) |
| text (input) | `on_change` | `newValue` (string), `element` (reference) |
| color_picker | `on_color_change` | `color` (table: {color, color_mode}) |
| color_picker | `on_brightness_change` | `newValue` (number 0-100), `element` |
| color_picker | `on_state_change` | `newValue` (boolean) |
| device_selector | `on_change` | `newValue` (JSON string) |

---

## 14. Common Patterns

### 14.1 Mode Selection with Buttons
```lua
-- Disable all mode buttons, enable selected one
function CustomDevice:updateModeButtons(activeMode)
  self:getElement('mode_auto'):setValue('enabled', activeMode == 0, true)
  self:getElement('mode_cool'):setValue('enabled', activeMode ~= 1, true)
  self:getElement('mode_heat'):setValue('enabled', activeMode ~= 4, true)
end
```

### 14.2 Slider with Feedback Display
```lua
function CustomDevice:onSetpoint(newValue)
  -- Update hardware
  self:getComponent('com'):writeHoldingRegisterAsync(18, math.floor(newValue))
  
  -- Update feedback display
  self:getElement('setpoint_fb'):setValue('value', 
    string.format('%.1f°C', newValue), true)
end
```

### 14.3 Combo Box Options from Lua
```lua
-- Combo box options are defined in JSON, but you can read the current value
local currentMode = self:getElement('mode_cb'):getValue('value')

-- And set it programmatically
self:getElement('mode_cb'):setValue('value', 'cooling', false)  -- Triggers callback
self:getElement('mode_cb'):setValue('value', 'cooling', true)   -- Silent update
```

---

*Document Version: 2.0*
*Based on analysis of: Erlelo, Samsung HE, Hue Controller, XK76 AC*

---

## 15. Statistics System (Data Collection)

The Sinum platform includes a built-in statistics system for collecting, storing, and querying time-series data. This is accessed via the global `statistics` object.

### 15.1 Adding Data Points

```lua
statistics:addPoint(name, value, unit)
```

**Parameters:**
- `name` (string): User-defined series name (e.g., "temperature", "humidity")
- `value` (number): The value to record
- `unit` (unit): Unit constant (see table below)

**Returns:** `boolean` - `true` if point was added, `false` if throttled

**Throttling:** Maximum 60 points per minute per series/device combination. Pool refills 1 point/minute.

### 15.2 Statistics Units

| Unit | Constant | Description |
|------|----------|-------------|
| °C | `unit.celsius` | Temperature (integer) |
| 0.1°C | `unit.celsius_x10` | Temperature × 10 (e.g., 235 = 23.5°C) |
| % | `unit.percent` | Percentage |
| 0.1% | `unit.percent_x10` | Percentage × 10 |
| 0.1% RH | `unit.relative_humidity_x10` | Relative humidity × 10 |
| W | `unit.watt` | Power (watts) |
| kW | `unit.kw_x10` | Kilowatts × 10 |
| Wh | `unit.wh` | Energy (watt-hours) |
| kWh | `unit.kwh` | Energy (kilowatt-hours) |
| V | `unit.volt` | Voltage |
| mV | `unit.millivolts` | Millivolts |
| A | `unit.ampere` | Current |
| mA | `unit.milliamp` | Milliamps |
| Pa | `unit.pascal` | Pressure |
| hPa | `unit.hectopascals_x10` | Hectopascals × 10 |
| PPM | `unit.ppm` | Parts per million |
| lx | `unit.lux` | Light level |
| L | `unit.litres` | Volume |
| L/h | `unit.liters_per_hour` | Flow rate |
| m³ | `unit.m3` | Volume |
| m³/h | `unit.m3_H` | Flow rate |
| 0/1 | `unit.bool_unit` | Boolean (0 or 1) |
| (none) | `unit.null` | Dimensionless |

### 15.3 Example: Recording Temperature Data

```lua
-- In onEvent or timer callback
function CustomDevice:recordStats()
  -- Get current temperature (int*10 format)
  local temp = kamra_homerseklet_v1:getValue()
  
  -- Record to statistics (value is already in x10 format)
  local success = statistics:addPoint("temperature", temp, unit.celsius_x10)
  
  if not success then
    print("Statistics throttled - too many points")
  end
  
  -- Record humidity
  local humi = kamra_para_v1:getValue()
  statistics:addPoint("humidity", humi, unit.relative_humidity_x10)
  
  -- Record boolean state
  local heating_on = signal.heat and 1 or 0
  statistics:addPoint("heating_active", heating_on, unit.bool_unit)
end
```

### 15.4 Querying Statistics

```lua
statistics:query(queryData)
statistics:onQueryResult(callback)
```

**Query Parameters:**
```lua
local queryData = {
  property = "temperature",           -- Required: series name
  time_start = 1745418251,           -- Optional: Unix timestamp or ISO string (UTC)
  time_end = 1745926579,             -- Optional: Unix timestamp or ISO string (UTC)
  sources = {                         -- Optional: specific devices
    {
      id = device:getValue("id"),
      class = device:getValue("class")
    }
  }
}
```

**Source Classes:**
- `scene`, `automation`, `custom_device_module`
- `wtp`, `tech`, `virtual`, `sbus`, `slink`, `lora`, `modbus`
- `energy_consumption`, `energy_production`, `energy_storage`
- `system_module`, `alarm_system`

### 15.5 Example: Query Last Hour's Data

```lua
-- Query setup
function CustomDevice:queryLastHour()
  local device = wtp[5]  -- or self for current device
  
  local queryData = {
    property = "humidity",
    time_start = utils.time:toISO(
      dateTime:getTotalTime() - 3600,  -- 1 hour ago
      utils.time.utc
    ),
    sources = {
      {
        id = device:getValue("id"),
        class = device:getValue("class")
      }
    }
  }
  
  statistics:query(queryData)
end

-- Callback handler (called when data arrives)
statistics:onQueryResult(function(queryData, status, result)
  if not status then
    print("Query failed")
    return
  end
  
  -- Process results
  local min_val, max_val = nil, nil
  for _, point in pairs(result) do
    local value = point["value"]
    if min_val == nil or value < min_val then min_val = value end
    if max_val == nil or value > max_val then max_val = value end
  end
  
  print("Min: " .. (min_val or "N/A") .. ", Max: " .. (max_val or "N/A"))
end)
```

### 15.6 Result Data Structure

Each point in the result array:
```lua
{
  id = 123,           -- Source device ID
  class = "sbus",     -- Source class
  name = "temperature", -- Property name
  unit = "celsius_x10", -- Unit string
  value = 235         -- The value (23.5°C in this case)
}
```

### 15.7 Best Practices

1. **Use consistent naming**: Same `name` parameter for related data series
2. **Match units to format**: If storing int×10 values, use `_x10` units
3. **Throttle awareness**: Don't call `addPoint` more than once per second per series
4. **Query limits**: Maximum 5 simultaneous queries globally
5. **UTC timestamps**: Always use UTC for `time_start` and `time_end`

### 15.8 Erlelo Integration Example

```lua
-- Add to timer callback (every 60 seconds recommended)
function CustomDevice:recordAllStats()
  -- Chamber conditions
  statistics:addPoint("chamber_temp", kamra_homerseklet_v1:getValue(), unit.celsius_x10)
  statistics:addPoint("chamber_humidity", kamra_para_v1:getValue(), unit.relative_humidity_x10)
  
  -- Supply air
  statistics:addPoint("supply_temp", befujt_homerseklet_akt1:getValue(), unit.celsius_x10)
  statistics:addPoint("supply_humidity", befujt_para_akt1:getValue(), unit.relative_humidity_x10)
  
  -- Targets
  statistics:addPoint("target_temp", kamra_cel_homerseklet_v1:getValue(), unit.celsius_x10)
  statistics:addPoint("target_humidity", kamra_cel_para_v1:getValue(), unit.relative_humidity_x10)
  
  -- Control states (as 0/1)
  statistics:addPoint("heating_on", signal.heat and 1 or 0, unit.bool_unit)
  statistics:addPoint("cooling_on", signal.cool and 1 or 0, unit.bool_unit)
  statistics:addPoint("dehumidify_on", signal.dehumi and 1 or 0, unit.bool_unit)
end
```

